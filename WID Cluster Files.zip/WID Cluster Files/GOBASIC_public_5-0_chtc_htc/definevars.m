% *************************************************************************
% Description: Define varibles and paths for a fitting job
% Author: Mary L. Radhuber
% Date: April 24, 2013
% Developer: Luyao Zou
% v2.0: Dec. 25, 2013
% v2.1: Mar. 28, 2014
% v3.2: Aug. 7, 2014
% v4.1: Sept. 13, 2014
% v4.3: Feb. 14, 2015 HAPPY VALENTINE'S DAY
% v4.4: Jun. 18, 2015
% v4.5: Dec. 1, 2015
% v5.0: Feb. 3, 2017
% *************************************************************************

% >>>>>>>>>>>> OBSERVATIONAL DATA SECTION >>>>>>>>>>>>
%
% Set number of components to fit
comp_num = 2;
%
% Path of observational x,y data
obspath = 'input_pixel.csv';

% Aperture efficiency of the telescope 
% % Except it's actually main beam efficiency, see analysisscript.m line 44
% % main beam Temp = antenna Temp / main beam efficiency
% % - Catherine Walker
apeff = 1;
%
% This 'range' is used to generate 'jlabel'. The value is determined
% by the user, which stands for how many datapoints on each side of the 
% molecular line center are going to be used to calculate gaussian line
% profile. Usually 10*fwhm/(sampling interval) is enough.
% DO NOT CHANGE this value! Changing it will cause error in including 
% previous fitting results.
range = 200;
%%
% Source sizes for each component. If 0, no beam-filling factor is accounted.
% If the source is not circular, please enter the HPFD of the equivilant
% circular Gaussian profile.
% Unit in arcsec. Numbers of source sizes should match 'comp_num'
sourcesize = zeros(comp_num,1);
% Dish diameter of the telescope in meter
dish = 368;
%
% Frequency ranges to be flagged. Enter frequency window in MHz row by row.
% Leave blank as "flagfreq = [];" if no flagging is needed.
flagfreq = [135412,142920; %middle
     146612,146622; %methanol maser 146618
     132886,132898; %methanol maser 132890
%%%%%%% Middle
       %143860,143872; %optically thick 143866 Middle
%%%%%%% S-1
       %143860,143872; %optically thick 143866 S-1
%%%%%%% S-2
%       133600,133608; %barely optically thick 133604
%       143860,143872; %optically thick 143866 S-1
%%%%%%% N-1
        %133600,133608; %barely optically thick 133604
%%%%%%% N-2
%        133600,133608; %barely optically thick 133604
%        143860,143872; %optically thick 143866 N-2
%%%%%%% N-3
%        143860,143872; %optically thick 143866 N-3
%        146362,146378; %optically thick 146370 N-3
%%%%%%% Left
%        133600,133608; %barely optically thick 133604
%        143860,143872; %optically thick 143866 Left
    ];
%
% Propogate uncertantity from (true) fit,
% (false) noise level before deconvolution
ta_err_from_fit = true; % Default is true
% noise level of antenna temperature (K)
ta_err_deconv = .03; % discarded if ta_err_from_fit = true

% >>>>>>>>>>>> CATALOG SECTION >>>>>>>>>>>>
%
% 'molpath' define catalog paths. Must match 'comp_num'
% 'parpath' define partition function data paths. Must match 'comp_num'
% 'label' define labels for each components for output. Must match 'comp_num'
% 'label' can be left blank if one is too lazy to type in any names.

molpath = {
           'CatalogFile/CH3OH_CDMS.txt';
           'CatalogFile/H2CO.txt';
           %'more files';
           };

parpath = {
           'CatalogFile/CH3OH_CDMS.par';
           'CatalogFile/H2COpar.par';
           %'more files';
           };

parco = {
         'CatalogFile/CH3OHpar.co';
         'CatalogFile/CH3OH_CDMS.co';
         %'more files';
        };

label = {
         'CH3OH';
         'H2CO';
         %'more names';
         };
%
% The transition frequency uncertanty cut-off in MHz from the catalog.
% Frequencies with uncertainty exeeding this cut-off will not be imported.
% 0 if no cut-off desired.
freq_uc_cutoff = 1;
% The log intensity cut-off from the catalog. Transistions weaker than this
% cut-off will not be imported. Should be a negative number.
% 0 if no cut-off desired.
int_cutoff = 0;
% The lower state energy cut-off from the catalog. Lower state energy larger
% than the cut-off will not be imported. Unit in wavenumbers.
% 0 if no cut-off specified.
elow_cutoff = 0;

% >>>>>>>>>>>> FIT PARAMETER SECTION  >>>>>>>>>>>> 
%
% Options for 'patternsearch' algorithm. Customize when necessary.
options = psoptimset('Display','iter','MaxIter',500000,'MaxFunEval',...
    500000*comp_num*5,'MaxMeshSize',Inf,'MeshAccelerator','On',...
    'ScaleMesh','On','UseParallel','Always','CompletePoll','On',...
    'TolMesh',1e-10,'TolX',1e-10,'TolFun',1e-10,'InitialMeshSize',1);

% Boundaries and initial guess of fitted parameters. Must match 'comp_num'
% The four paramters are:
% log(NT) (log10 cm^(-2)), FWHM (km/s), 0.01*Temp (100K), Shift (km/s)
low = repmat([12;0.50;0.01;-12],1,comp_num);%13;1.00;0.05;-8

up = repmat([19;20;5.00;12],1,comp_num);%19;20;5.00;3

%init = repmat([14.15;5.14;0.3143;4.85],1,comp_num);%15;5;1.5;0
%N-2 works f
init=[14.95,14.09;
      3.77,3.49;
      0.1672,0.2760;
      1.42,1.47;
];

% The fraction used in calculating uncertainty
tol = 1e-3;

% >>>>>>>>>>>> OUTPUT & PREVIOUS FITS SECTION  >>>>>>>>>>>> 
%
% Define output path and file name. 
outputpath = './'; % Don't forget the last '/'
outputname = 'input_pixel'; % This will result in three output files, named 
% respectively 'input_pixel_Fit.csv', 'input_pixel_Results.csv', and 
% 'input_pixel_Table.csv'. - Alex Sandquist
%
% Include previous fits. Only compatible with v4.0 or later versions
pfitpath = {%'../Fitv5.0/HifiBand2/W75N/W75N_FINAL_IX-MOL_Fit.csv';
            %etc;
           };
