#!/bin/bash

# This file is the executable shell script that the submit file runs to queue the jobs.
cd inputs
# Move the working directory to the transferred inputs directory.

mv *.csv ../GOBASIC_public_5-0_chtc_htc/input_pixel.csv
# Each job is first moved to its own computing machine prior to this shell script being run. This line of code renames the unique input spectrum file's name to input_file.csv and transfers it to the GOBASIC folder...
# ...  so that the definevars.m script does not need a unique identifier to call each input spectrum. Setting Obspath = input_file.csv in GOBASIC will call the appropriate input csv file.

cd ../GOBASIC_public_5-0_chtc_htc
#This line is setting the working directory of the execution point to the GOBASIC_public_5-0_chtc_htc folder transferred by the submit file.

matlab -batch "Run"
# This runs the Run.m script.

# The HTCondor submit script will handle providing unique names for each output file, so that they no longer have the generic name.
# Make sure that in definevars.m, Obspath = input_pixel.csv (and if there is unique file pathing, ensure that is included as well).
