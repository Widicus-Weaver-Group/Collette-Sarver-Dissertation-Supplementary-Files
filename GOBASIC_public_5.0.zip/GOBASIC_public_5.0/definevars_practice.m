% *************************************************************************
% Description: Define varibles and paths for a fitting job
% Author: Mary L. Radhuber
% Date: April 24, 2013
% Developer: Luyao Zou
% v2.0: Dec. 25, 2013
% v2.1: Mar. 28, 2014
% v3.2: Aug. 7, 2014
% v4.1: Sept. 13, 2014
% v4.3: Feb. 15, 2015
% v4.4: Jun. 18, 2015
% v4.5: Dec. 1, 2015
% v5.0: Feb. 3, 2017
% *************************************************************************

% >>>>>>>>>>>> OBSERVATIONAL DATA SECTION >>>>>>>>>>>>
%
% Set number of components to fit
comp_num = 3;
%
% Path of observational x,y data
obspath = '../Observation/L1157.csv';
% Aperture efficiency of the telescope
apeff = 0.57;
%
% This 'range' is used to generate 'jlabel'. The value is determined
% by the user, which stands for how many datapoints on each side of the 
% molecular line center are going to be used to calculate gaussian line
% profile. Usually 10*fwhm/(sampling interval) is enough.
% DO NOT CHANGE this value! Changing it will cause error in including 
% previous fitting results.
range = 200;
%
% Source sizes for each component. If 0, no beam-filling factor is accounted.
% If the source is not circular, please enter the HPFD of the equivilant
% circular Gaussian profile.
% Unit in arcsec. Numbers of source sizes should match 'comp_num'
sourcesize = zeros(1,comp_num);
% Dish diameter of the telescope in meter
dish = 10.4;
%
% Frequency ranges to be flagged. Enter frequency window in MHz row by row.
% Leave blank as "flagfreq = [];" if no flagging is needed.
flagfreq = [% flag C18O, 13CO, C17O, CO;
            %219550,219560;220390,220400;224700,224720;230510,230550; % B1B flags
            %219550,219570;220380,220410;224700,224730;230510,230580; % DR21OH flags
            %220360,220420;224700,224730;230400,230600; % G12.21 flags
            %219550,219570;220360,220440;224710,224730;230450,230600; % G12.91 flags
            %219720,219760;220370,220420;224690,224730;230450,230600; % G19.61 flags
            %224690,224730;230500,230650; % G24.33 flags
            %219550,219580;220380,220460;224690,224730;230500,230640; % G24.78 flags
            %219560,219600;220580,220610; 230520,230630; % G29.96 flags
            %219550,219570;220390,220410;224690,224730;230500,230600; % G31.41 flags
            %219550,219570;220380,220420;224690,224730;230490,230610; % G34.3 flags
            %219555,219570;220390,220450;224705,224725;230520,230600; % G45.47 flags
            %219550,219570;220380,220420;224705,224730;230500,230560; % G75.78 flags
            %224680,224780;230420,230700; % GCM+0.693 flags
            %219555,219565;220390,220410;224710,224730;230510,230560; % HH80 flags
            220390,220430;230530,230560; % L1157 flags (this source doesn't have O isotopes)
            %219550,219565;220390,220400;224705,224715;230480,230600; % L1448MM flags
            %219555,219565;220390,220410;224710,224720;230520,230570; % NGC1333-2A flags
            %219550,219570;220100,220120;220390,220410;230530,230560; % NGC1333-2B flags
            %219550,219570;220390,220410;224710,224720,230510,230570; % NGC1333-4A flags
            %219550,219585;220380,220420;224700,224720;230500,230560; % NGC1333-4B flags
            %219550,219570;220380,220410;224700,224740;230500,230560; % NGC2264 flags
            %219940,219970;220380,220420;224690,224730;230500,230640; % NGC6334-29 flags
            %219550,219570;220390,220410;224700,224720;230500,230620; % NGC6334-38 flags
            %219550,219570;220390,220420;224705,224725;230500,230580; % NGC6334-43 flags
            %219550,219570;220390,220420;224710,224725;230510,230640; % NGC6334-IN flags
            %219550,219570;220380,220420;224700,224730;230510,230560; % NGC7538 flags
            %230400,230900; % Orion flags
            %220340,220440; 230400,230700; % SgrB2 flags
            %219550,219570;220380,220410;224690,224730;230480,230600; % W3 flags
            %219380,219430;219540,219580;220380,220420;224680,224720;230500,230580; % W51 flags
            %224700,224730;230500,230590;257410,257445; % W75N flags
            %661000,661120;658520,658600;673960,674060; % HifiBand2 flags
            ];
%
% Propogate uncertantity from (true) fit,
% (false) noise level before deconvolution
ta_err_from_fit = true; % Default is true
% noise level of antenna temperature (K)
ta_err_deconv = .03; % discarded if ta_err_from_fit = true

% >>>>>>>>>>>> CATALOG SECTION >>>>>>>>>>>>
%
% 'molpath' define catalog paths. Must match 'comp_num'
% 'parpath' define partition function data paths. Must match 'comp_num'
% 'label' define labels for each components for output. Must match 'comp_num'
% 'label' can be left blank if one is too lazy to type in any names.

molpath = {
           '../CatalogFile/CH3OH_CDMS.txt';
           %'../CatalogFile/SiO.txt';
           '../CatalogFile/SO.txt';
           '../CatalogFile/CN.txt';
           %'../CatalogFile/CS.txt';
           %'../CatalogFile/H2CO.txt';
           %'../CatalogFile/HCN.txt';
           };

parpath = {
           '../CatalogFile/CH3OH_CDMS.par';
           %'../CatalogFile/SiOpar.par';
           '../CatalogFile/SOpar.par';
           '../CatalogFile/CNpar.par';
           %'../CatalogFile/CSpar.par';
           %'../CatalogFile/H2COpar.par';
           %'../CatalogFile/HCNpar.par';
           };

parco = {
         '../CatalogFile/CH3OH_CDMS.co';
         %'../CatalogFile/SiOpar.co';
         '../CatalogFile/SOpar.co';
         '../CatalogFile/CNpar.co';
         %'../CatalogFile/CSpar.co';
         %'../CatalogFile/H2COpar.co';
         %'../CatalogFile/HCNpar.co';
        };

label = {
         'CH3OH';
         %'SiO';
         'SO';
         'CN';
         %'CS'
         %'H2CO';
         %'HCN';
         };
%
% The transition frequency uncertanty cut-off in MHz from the catalog.
% Frequencies with uncertainty exeeding this cut-off will not be imported.
% 0 if no cut-off desired.
freq_uc_cutoff = 1;
% The log intensity cut-off from the catalog. Transistions weaker than this
% cut-off will not be imported. Should be a negative number.
% 0 if no cut-off desired.
int_cutoff = 0;
% The lower state energy cut-off from the catalog. Lower state energy larger
% than the cut-off will not be imported. Unit in wavenumbers.
% 0 if no cut-off specified.
elow_cutoff = 0;

% >>>>>>>>>>>> FIT PARAMETER SECTION  >>>>>>>>>>>> 
%
% Options for 'patternsearch' algorithm. Customize when necessary.
options = psoptimset('Display','iter','MaxIter',70000,'MaxFunEval',...
    1000000*comp_num*5,'MaxMeshSize',Inf,'MeshAccelerator','On',...
    'ScaleMesh','On','UseParallel','Always','CompletePoll','On',...
    'TolMesh',1e-10,'TolX',1e-10,'TolFun',1e-10,'InitialMeshSize',1);

% Boundaries and initial guess of fitted parameters. Must match 'comp_num'
% The four paramters are:
% log(NT) (log10 cm^(-2)), FWHM (km/s), 0.01*Temp (100K), velocity Shift (km/s)
low = repmat([10;2;0;-5],1,comp_num);

up = repmat([20;10;0.5;2],1,comp_num);

init = repmat([15;5;0.1;0],1,comp_num);

% The fraction used in calculating uncertainty
tol = 1e-3;

% >>>>>>>>>>>> OUTPUT & PREVIOUS FITS SECTION  >>>>>>>>>>>> 
%
% Define output path and file name. 
outputpath = '../Fit/'; % Don't forget the last '/'
outputname = 'Total';
%
% Include previous fits. Only compatible with v4.0 or later versions
pfitpath = {
            '../Fit/CSFit.csv';
            '../Fit/SiOFit.csv';
            '../Fit/H2COFit.csv';
            '../Fit/HCNFit.csv';
           };