% *************************************************************************
% Description: Define varibles and paths for a fitting job
% Author: Mary L. Radhuber
% Date: April 24, 2013
% Developer: Luyao Zou
% v2.0: Dec. 25, 2013
% v2.1: Mar. 28, 2014
% v3.2: Aug. 7, 2014
% v4.1: Sept. 13, 2014
% v4.3: Feb. 15, 2015
% v4.4: Jun. 18, 2015
% v4.5: Dec. 1, 2015
% v5.0: Feb. 3, 2017
% *************************************************************************

% >>>>>>>>>>>> OBSERVATIONAL DATA SECTION >>>>>>>>>>>>
%
% Set number of components to fit
comp_num = 1;
%
% Path of observational x,y data
obspath = '../Observation/IRAS-4B-LSB-LC-spectrum-k-base-total.csv';
% Main beam efficiency of the telescope
apeff = 1;
%
% This 'range' is used to generate 'jlabel'. The value is determined
% by the user, which stands for how many datapoints on each side of the 
% molecular line center are going to be used to calculate gaussian line
% profile. Usually 10*fwhm/(sampling interval) is enough.
% DO NOT CHANGE this value! Changing it will cause error in including 
% previous fitting results.
range = 200;
%
% Source sizes for each component. If 0, no beam-filling factor is accounted.
% If the source is not circular, please enter the HPFD of the equivilant
% circular Gaussian profile.
% Unit in arcsec. Numbers of source sizes should match 'comp_num'
sourcesize = zeros(1,comp_num);
% Dish diameter of the telescope in meter
dish = 1400;
%
% Frequency ranges to be flagged. Enter frequency window in MHz row by row.
% Leave blank as "flagfreq = [];" if no flagging is needed.
flagfreq = [];%234126.0834, 236876.7384

%
% Propogate uncertantity from (true) fit,
% (false) noise level before deconvolution
ta_err_from_fit = true; % Default is true
% noise level of antenna temperature (K)
ta_err_deconv = .03; % discarded if ta_err_from_fit = true

% >>>>>>>>>>>> CATALOG SECTION >>>>>>>>>>>>
%
% 'molpath' define catalog paths. Must match 'comp_num'
% 'parpath' define partition function data paths. Must match 'comp_num'
% 'label' define labels for each components for output. Must match 'comp_num'
% 'label' can be left blank if one is too lazy to type in any names.

molpath = {
           %'../CatalogFile/CH3OH_CDMS.txt';
           %'../CatalogFile/CH3OCH3.txt';
           %'../CatalogFile/HCOOCH3.txt';
           %'../CatalogFile/C-13-H3OH.txt';
           %'../CatalogFile/SO2.txt';
           %'../CatalogFile/CH3CN.txt';
           %'../CatalogFile/C2H3CN-15.txt'
           %'../CatalogFile/H2CS.txt'
           %'../CatalogFile/SiO.txt';
           %'../CatalogFile/SO.txt';
           %'../CatalogFile/CN.txt';
           %'../CatalogFile/CS.txt';
           %'../CatalogFile/OCS.txt'
           %'../CatalogFile/H2CO.txt';
           %'../CatalogFile/HCN.txt';
           %'../CatalogFile/C4H.txt';
           %'../CatalogFile/Acetone.txt';
           %'../CatalogFile/t-HCOOH.txt';
           %'../CatalogFile/CH3OCHO.txt';
           %'../CatalogFile/C2H5CN.txt';
           %'../CatalogFile/C2H3CN.txt';
           %'../CatalogFile/CH3O-13-CHO.txt';
           %'../CatalogFile/HDCO.txt';
           %'../CatalogFile/CH3CHO.txt';
           %'../CatalogFile/c-C2H4O.txt';
           %'../CatalogFile/CH3CCH.txt';
           %'../CatalogFile/CH2NH.txt';
           %'../CatalogFile/H2CCO.txt';
           %'../CatalogFile/HCCCN.txt';
           %'../CatalogFile/HCOOH.txt';
           %'../CatalogFile/NH2CHO.txt';
           %'../CatalogFile/C2H5OH.txt';
           %'../CatalogFile/c-HCCCH.txt';
           %'../CatalogFile/HCOCN.txt'
           %'../CatalogFile/13-CH3CN.txt'
           %'../CatalogFile/S-18-O.txt'
           %'../CatalogFile/29-SiC2.txt'
           %'../CatalogFile/CH2OHCHO.txt'
           %'../CatalogFile/H2S.txt'
           %'../CatalogFile/i-C3H7CN.txt'
           %'../CatalogFile/H2CS-34.txt'
           %'../CatalogFile/gGg-glycol.txt'
           %'../CatalogFile/aGg-glycol.txt'
           '../CatalogFile/CH3COOH.txt'
           };

parpath = {
           %'../CatalogFile/CH3OH_CDMS.par';
           %'../CatalogFile/CH3OCH3par.par';
           %'../CatalogFile/HCOOCH3par.par';
           %'../CatalogFile/C-13-H3OHpar.par';
           %'../CatalogFile/SO2par.par';
           %'../CatalogFile/CH3CNpar.par';
           %'../CatalogFile/C2H3CN-15par.par';
           %'../CatalogFile/H2CSpar.par'
           %'../CatalogFile/SiOpar.par';
           %'../CatalogFile/SOpar.par';
           %'../CatalogFile/CNpar.par';
           %'../CatalogFile/CSpar.par';
           %'../CatalogFile/OCSpar.par';
           %'../CatalogFile/H2COpar.par';
           %'../CatalogFile/HCNpar.par';
           %'../CatalogFile/C4Hpar.par';
           %'../CatalogFile/Acetonepar.par';
           %'../CatalogFile/t-HCOOHpar.par';
           %'../CatalogFile/CH3OCHOpar.par';
           %'../CatalogFile/C2H5CNpar.par';
           %'../CatalogFile/C2H3CNpar.par';
           %'../CatalogFile/CH3O-13-CHOpar.par';
           %'../CatalogFile/HDCOpar.par';
           %'../CatalogFile/CH3CHOpar.par';
           %'../CatalogFile/c-C2H4Opar.par'
           %'../CatalogFile/CH3CCHpar.par'
           %'../CatalogFile/CH2NHpar.par'
           %'../CatalogFile/H2CCOpar.par'
           %'../CatalogFile/HCCCNpar.par'
           %'../CatalogFile/HCOOHpar.par'
           %'../CatalogFile/NH2CHOpar.par'
           %'../CatalogFile/C2H5OHpar.par'
           %'../CatalogFile/c-HCCCHpar.par'
           %'../CatalogFile/HCOCNpar.par'
           %'../CatalogFile/13-CH3CNpar.par'
           %'../CatalogFile/S-18-Opar.par'
           %'../CatalogFile/29-SiC2par.par'
           %'../CatalogFile/CH2OHCHOpar.par'
           %'../CatalogFile/H2Spar.par'
           %'../CatalogFile/i-C3H7CNpar.par'
           %'../CatalogFile/H2CS-34par.par'
           %'../CatalogFile/gGg-glycolpar.par'
           %'../CatalogFile/aGg-glycolpar.par'
           '../CatalogFile/CH3COOH.par'
           };

parco = {
         %'../CatalogFile/CH3OH_CDMS.co';
         %'../CatalogFile/CH3OCH3par.co';
         %'../CatalogFile/HCOOCH3par.co';
         %'../CatalogFile/C-13-H3OHpar.co';
         %'../CatalogFile/SO2par.co';
         %'../CatalogFile/CH3CNpar.co';
         %'../CatalogFile/C2H3CN-15par.co'
         %'../CatalogFile/H2CSpar.co'
         %'../CatalogFile/SiOpar.co';
         %'../CatalogFile/SOpar.co';
         %'../CatalogFile/CNpar.co';
         %'../CatalogFile/CSpar.co';
         %'../CatalogFile/OCSpar.co';
         %'../CatalogFile/H2COpar.co';
         %'../CatalogFile/HCNpar.co';
         %'../CatalogFile/C4Hpar.co';
         %'../CatalogFile/Acetonepar.co';
         %'../CatalogFile/t-HCOOHpar.co';
         %'../CatalogFile/CH3OCHOpar.co';
         %'../CatalogFile/C2H5CNpar.co';
         %'../CatalogFile/C2H3CNpar.co';
         %'../CatalogFile/CH3O-13-CHOpar.co'
         %'../CatalogFile/HDCOpar.co'
         %'../CatalogFile/CH3CHOpar.co'
         %'../CatalogFile/c-C2H4Opar.co'
         %'../CatalogFile/CH3CCHpar.co'
         %'../CatalogFile/CH2NHpar.co'
         %'../CatalogFile/H2CCOpar.co'
         %'../CatalogFile/HCCCNpar.co'
         %'../CatalogFile/HCOOHpar.co'
         %'../CatalogFile/NH2CHOpar.co'
         %'../CatalogFile/C2H5OHpar.co'
         %'../CatalogFile/c-HCCCHpar.co'
         %'../CatalogFile/HCOCNpar.co'
         %'../CatalogFile/13-CH3CNpar.co'
         %'../CatalogFile/S-18-Opar.co'
         %'../CatalogFile/29-SiC2par.co'
         %'../CatalogFile/CH2OHCHOpar.co'
         %'../CatalogFile/H2Spar.co'
         %'../CatalogFile/i-C3H7CNpar.co'
         %'../CatalogFile/H2CS-34par.co'
         %'../CatalogFile/gGg-glycolpar.co'
         %'../CatalogFile/aGg-glycolpar.co'
         '../CatalogFile/CH3COOH.co'
         };

label = {
         %'CH3OH';
         %'CH3OCH3';
         %'HCOOCH3';
         %'C-13-H3OH';
         %'SO2';
         %'CH3CN';
         %'C2H3CNv15';
         %'H2CS';
         %'SiO';
         %'SO';
         %'CN';
         %'CS';
         %'OCS';
         %'H2CO';
         %'HCN';
         %'C4H';
         %'Acetone'
         %'t-HCOOH'
         %'CH3OCHO'
         %'C2H5CN';
         %'C2H3CN';
         %'CH3O-13-CHO'
         %'HDCO'
         %'CH3CHO'
         %'c-C2H4O'
         %'CH3CCH'
         %'CH2NH'
         %'H2CCO'
         %'HCCCN'
         %'HCOOH'
         %'NH2CHO'
         %'C2H5OH'
         %'c-HCCCH'
         %'HCOCN'
         %'13-CH3CN'
         %'S-18-O'
         %'29-SiC2'
         %'CH2OHCHO'
         %'H2S'
         %'C2H3C-13-N'
         %'i-C3H7CN'
         %'H2CS-34'
         %'Ethylene-glycol-gGg'
         %'Ethylene-glycol-aGg'
         'CH3COOH'
         };
%
% The transition frequency uncertanty cut-off in MHz from the catalog.
% Frequencies with uncertainty exeeding this cut-off will not be imported.
% 0 if no cut-off desired.
freq_uc_cutoff = 1;
% The log intensity cut-off from the catalog. Transistions weaker than this
% cut-off will not be imported. Should be a negative number.
% 0 if no cut-off desired.
int_cutoff = 0;
% The lower state energy cut-off from the catalog. Lower state energy larger
% than the cut-off will not be imported. Unit in wavenumbers.
% 0 if no cut-off specified.
elow_cutoff = 0;

% >>>>>>>>>>>> FIT PARAMETER SECTION  >>>>>>>>>>>> 
%
% Options for 'patternsearch' algorithm. Customize when necessary.
options = psoptimset('Display','iter','MaxIter',50000,'MaxFunEval',...
    50000*comp_num*5,'MaxMeshSize',Inf,'MeshAccelerator','On',...
    'ScaleMesh','On','UseParallel','Always','CompletePoll','On',...
    'TolMesh',1e-10,'TolX',1e-10,'TolFun',1e-10,'InitialMeshSize',1);

% Boundaries and initial guess of fitted parameters. Must match 'comp_num'
% The four paramters are:
% log(NT) (log10 cm^(-2)), FWHM (km/s), 0.01*Temp (100K), velocity Shift (km/s)
low = repmat([13;1.00;0.05;-8],1,comp_num);%13;1.00;0.05;-8

up = repmat([19;20;7.00;3],1,comp_num);%19;20;5.00;3

init = repmat([15;5;1.5;0],1,comp_num);%15;5;1.5;0

% The fraction used in calculating uncertainty
tol = 1e-3;

% >>>>>>>>>>>> OUTPUT & PREVIOUS FITS SECTION  >>>>>>>>>>>> 
%
% Define output path and file name. 
outputpath = '../Fit/IRAS-4B-LSB-LC/'; % Don't forget the last '/'
outputname = 'acetic_acid';
%
% Include previous fits. Only compatible with v4.0 or later versions
pfitpath = {
%             '../Fit/dr21oh_fit-baselinecorr/SO2-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/C4H-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/t-HCOOH-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/H2CO-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/H2CS-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/CH3CCH-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/CH2NH-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/CH3OCHO-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/HCOOH-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/c-HCCCH-locked-cutoff4Fit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/C2H5CN-locked-cutoff2.65Fit.csv';
%             %'../Fit/dr21oh_fit-baselinecorr/CH3O-13-CHO-locked-cutoff4.3Fit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/HDCO-locked-cutoff3.9Fit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/C2H3CN-locked-cutoff3.13Fit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/HCOCN-lockedFit.csv';
%             %
%             '../Fit/dr21oh_fit-baselinecorr/CH3OH-1-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/CH3OCH3-2-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/HCOOCH3-3-lockedFit.csv';
%             '../Fit/dr21oh_fit-baselinecorr/C-13-H3OH-4-lockedFit.csv';
           
           };