%{
% *************************************************************************
% Description: Define varibles and paths for a fitting job
% Author: Mary L. Radhuber
% Date: April 24, 2013
% Developer: Luyao Zou
% v2.0: Dec. 25, 2013
% v2.1: Mar. 28, 2014
% v3.2: Aug. 7, 2014
% v4.1: Sept. 13, 2014
% v4.3: Feb. 15, 2015
% v4.4: Jun. 18, 2015
% v4.5: Dec. 1, 2015
% v5.0: Feb. 3, 2017
% *************************************************************************
% >>>>>>>>>>>> OBSERVATIONAL DATA SECTION >>>>>>>>>>>>
%}
% Set number of components to fit
comp_num = 1;
%
% Path of observational x,y data
obspath = '../Observation/fullrc.csv';
% Aperture efficiency of the telescope
apeff = 1;

%{
% This 'range' is used to generate 'jlabel'. The value is determined
% by the user, which stands for how many datapoints on each side of the 
% molecular line center are going to be used to calculate gaussian line
% profile. Usually 10*fwhm/(sampling interval) is enough.
% DO NOT CHANGE this value! Changing it will cause error in including 
% previous fitting results.
%}
range = 100; %typically 200
%
% Source sizes for each component. If 0, no beam-filling factor is accounted.
% If the source is not circular, please enter the HPFD of the equivilant
% circular Gaussian profile.
% Unit in arcsec. Numbers of source sizes should match 'comp_num'
sourcesize = zeros(1,comp_num);
%sourcesize = repmat(2.53,1,comp_num); % use this if we know the size

% Dish diameter of the telescope in meter
dish = 368.0; %normally 368
%
% Frequency ranges to be flagged. Enter frequency window in MHz row by row.
% Leave blank as "flagfreq = [];" if no flagging is needed.

flagfreq = [ 135480.3438, 142882.5625;
            ];



% Propogate uncertantity from (true) fit,
% (false) noise level before deconvolution
ta_err_from_fit = true; % Default is true
% noise level of antenna temperature (K)
ta_err_deconv = .03; % discarded if ta_err_from_fit = true

% >>>>>>>>>>>> CATALOG SECTION >>>>>>>>>>>>
%
% 'molpath' define catalog paths. Must match 'comp_num'
% 'parpath' define partition function data paths. Must match 'comp_num'
% 'label' define labels for each components for output. Must match 'comp_num'
% 'label' can be left blank if one is too lazy to type in any names.

molpath = {
		   %'../cats/PA.txt'
           %'../cats/2CE.txt'
           '../CatalogFile/CH3OH_CDMS.txt';
           %'../cats/CH3SH.txt';
           %'../cats/CH2NH.txt';
           %'../cats/CH3C-13-H2CN.txt';
           %'../cats/SiCC.txt';
           %'../cats/CH3CN.txt';
		   %'../cats/CH2OHCHO.txt';
           %'../cats/CH3CNv8.txt';
		   %'../cats/C2H5CN.txt';
           %'../cats/C2H3CN.txt';
           %'../cats/HCOOCH3.txt';
           %'../cats/HCOOCH3.txt';
           %'../cats/HCCCN.txt'
           %'../cats/HCCCNv7.txt'
           %'../cats/CH3OCH3.txt';
           %'../cats/C2H3CN.txt';
           %'../cats/NH2CHO.txt';
           %'../cats/H2CO.txt';
		   %'../cats/CH3CCH.txt';
           %'../cats/HNCO.txt';
           %'../cats/SiO.txt';
           %'../cats/SO.txt';
           %'../cats/S-33-O.txt';
           %'../cats/HCS+.txt';
           %'../cats/SO2.txt';
           %'../cats/S-34-O2.txt';
           %'../cats/OCS.txt';
           %'../cats/NO.txt';
           %'../cats/HDO.txt'
           %'../cats/H2CS.txt'
           };

parpath = {
           %'../cats/PA.par'
           %'../cats/2CEpar.par'
		   '../CatalogFile/CH3OH_CDMS.par';
           %'../cats/CH3SHpar.par';
           %'../cats/CH2NHpar.par';
           %'../cats/CH3C-13-H2CNpar.par';
           %'../cats/SiCCpar.par';
		   %'../cats/CH3CNpar.par';
           %'../cats/CH2OHCHOpar.par';
           %'../cats/CH3CNv8par.par';
		   %'../cats/C2H5CNpar.par';
           %'../cats/C2H3CNpar.par';
           %'../cats/HCOOCH3par.par';
           %'../cats/HCOOCH3par.par';
           %'../cats/HCCCNpar.par'
           %'../cats/HCCCNv7par.par'
           %'../cats/CH3OCH3par.par';
           %'../cats/C2H3CNpar.par';
           %'../cats/NH2CHOpar.par';
           %'../cats/H2COpar.par';
		   %'../cats/CH3CCHpar.par';
           %'../cats/HNCOpar.par';
           %'../cats/SiOpar.par';
           %'../cats/SOpar.par';
           %'../cats/S-33-Opar.par';
           %'../cats/HCS+par.par';
           %'../cats/SO2par.par';
           %'../cats/S-34-O2par.par';
           %'../cats/OCSpar.par';
           %'../cats/NOpar.par';
           %'../cats/HDOpar.par'
           %'../cats/H2CSpar.par'
           };

parco =    {
           %'../cats/PA.co'
           %'../cats/2CEpar.co'
           '../CatalogFile/CH3OH_CDMS.co';
           %'../cats/CH3SHpar.co';
           %'../cats/CH2NHpar.co';
           %'../cats/CH3C-13-H2CNpar.co';
           %'../cats/SiCCpar.co';
		   %'../cats/CH3CNpar.co';
           %'../cats/CH2OHCHOpar.co';
           %'../cats/CH3CNv8par.co';
		   %'../cats/C2H5CNpar.co';
           %'../cats/C2H3CNpar.co';
           %'../cats/HCOOCH3par.co';
           %'../cats/HCOOCH3par.co';
           %'../cats/HCCCNpar.co'
           %'../cats/HCCCNv7par.co'
           %'../cats/CH3OCH3par.co';
           %'../cats/C2H3CNpar.co';
           %'../cats/NH2CHOpar.co';
           %'../cats/H2COpar.co';
		   %'../cats/CH3CCHpar.co';
           %'../cats/HNCOpar.co';
           %'../cats/SiOpar.co';
           %'../cats/SOpar.co';
           %'../cats/S-33-Opar.co';
           %'../cats/HCS+par.co';
           %'../cats/SO2par.co';
           %'../cats/S-34-O2par.co';
           %'../cats/OCSpar.co';
           %'../cats/NOpar.co';
           %'../cats/HDOpar.co'
           %'../cats/H2CSpar.co'
           };

label = {
		 %'Pyruvic Acid'
         %'2CE'
         'CH3OH';
         %'CH3SH'
		 %'CH3CN'
         %'CH3CNv8'
         %'Glycolal'
         %'C2H5CN';
         %'C2H3CN'
         %'C2-13-H5CN';
         %'HCOOCH3';
         %'HCOOCH3 T2';
         %'HCCCN'
         %'HCCCN v7'
         %'CH3OCH3';
         %'C2H3CN';
         %'NH2CHO';
         %'H2CO';
		 %'CH2NH';
         %'H2CN';
         %'HNCO';
         %'SiO';
         %'SO';
         %'HCS+';
         %'SO2';
         %'S-33-O'
         %'S-34-O2'
         %'OCS';
         %'NO';
         %'HDO'
         %'H2CS'
         };
%
% The transition frequency uncertanty cut-off in MHz from the catalog.
% Frequencies with uncertainty exeeding this cut-off will not be imported.
% 0 if no cut-off desired.
freq_uc_cutoff = 0;
% The log intensity cut-off from the catalog. Transistions weaker than this
% cut-off will not be imported. Should be a negative number.
% 0 if no cut-off desired.
int_cutoff = 0;
% The lower state energy cut-off from the catalog. Lower state energy larger
% than the cut-off will not be imported. Unit in wavenumbers.
% 0 if no cut-off specified.
elow_cutoff = 0;

% >>>>>>>>>>>> FIT PARAMETER SECTION  >>>>>>>>>>>> 
%
% Options for 'patternsearch' algorithm. Customize when necessary.
options = psoptimset('Display','iter','MaxIter',20000,'MaxFunEval',...
    30000*comp_num*5,'MaxMeshSize',Inf,'MeshAccelerator','On',...
    'ScaleMesh','On','UseParallel','Always','CompletePoll','On',...
    'TolMesh',1e-10,'TolX',1e-10,'TolFun',1e-10,'InitialMeshSize',1);

% Boundaries and initial guess of fitted parameters. Must match 'comp_num'
% The four paramters are:
% log(NT) (log10 cm^(-2)), FWHM (km/s), 0.01*Temp (100K), Shift (km/s)
low = repmat([14;3;0.1;-5],1,comp_num);

up = repmat([18;30;8;5],1,comp_num);

init = repmat([17;8;2.5;0],1,comp_num);

% The fraction used in calculating uncertainty
tol = 1e-3;

% >>>>>>>>>>>> OUTPUT & PREVIOUS FITS SECTION  >>>>>>>>>>>> 
%
% Define output path and file name. 
outputpath = '../Fit/'; % Don't forget the last '/'
outputname = 'willflagtest';
%
% Include previous fits. Only compatible with v4.0 or later versions
pfitpath = {
            
			%'../fit/SiO-upperFit.csv';
            %'../fit/SO-upperFit.csv';
            %'../fit/HCS+-upperFit.csv';
            %'../fit/HNCO-upperFit.csv';
            %'../fit/OCS-upperFit.csv';
            %'../fit/H2CO-upperFit.csv';
            %'../fit/NH2CHO-upperFit.csv';
            %'../fit/HDO-upperFit.csv';
            %'../fit/CS-upperFit.csv';
            %'../fit/CS-33-upperFit.csv';
            %'../fit/CS-34-upperFit.csv';
            %'../fit/H2C-13-O-upperFit.csv';
            %'../fit/NO-upperFit.csv';
            %'../fit/S-34-O-upperFit.csv';
            %'../fit/H2CS-upperFit.csv';
            %'../fit/HCCCNv7-upperFit.csv';
            %'../fit/S-34-O2-upperFit.csv';
			%'../fit/CH3CNv8-upperFit.csv';
            %'../fit/Left_Core_Best/LeftEdgeFullAnalysisPicked-lower_Fit.csv';
           };
