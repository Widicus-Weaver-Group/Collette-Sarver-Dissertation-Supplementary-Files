% *************************************************************************
% Description: Define varibles and paths for a fitting job
% Author: Mary L. Radhuber
% Date: April 24, 2013
% Developer: Luyao Zou
% v2.0: Dec. 25, 2013
% v2.1: Mar. 28, 2014
% v3.2: Aug. 7, 2014
% v4.1: Sept. 13, 2014
% v4.3: Feb. 15, 2015
% v4.4: Jun. 18, 2015
% v4.5: Dec. 1, 2015
% v5.0: Feb. 3, 2017
% *************************************************************************

% >>>>>>>>>>>> OBSERVATIONAL DATA SECTION >>>>>>>>>>>>
%
% Set number of components to fit
comp_num = 12;
%
% Path of observational x,y data
obspath = '../Observation/hifidata.class/GAL012.91-00.26_Band2_ssb_nc.ahv.hifi"';
% Aperture efficiency of the telescope
apeff = 0.76;
%
% This 'range' is used to generate 'jlabel'. The value is determined
% by the user, which stands for how many datapoints on each side of the 
% molecular line center are going to be used to calculate gaussian line
% profile. Usually 10*fwhm/(sampling interval) is enough.
% DO NOT CHANGE this value! Changing it will cause error in including 
% previous fitting results.
range = 600; 
%
% Source sizes for each component. If 0, no beam-filling factor is accounted.
% If the source is not circular, please enter the HPFD of the equivilant
% circular Gaussian profile.
% Unit in arcsec. Numbers of source sizes should match 'comp_num'
sourcesize = zeros(1,comp_num);
% Dish diameter of the telescope in meter
dish = 3.28;
%
% Frequency ranges to be flagged. Enter frequency window in MHz row by row.
% Leave blank as "flagfreq = [];" if no flagging is needed.
flagfreq = [% flag C18O, 13CO, C17O, CO;
            %219550,219560;220390,220400;224700,224720;230510,230550; % B1B flags
            %219550,219570;220380,220410;224700,224730;230510,230580; % DR21OH flags
            %220380,220410;224700,224730;230510,230620; % G10.47 flags
            %220360,220420;224700,224730;230400,230600; % G12.21 flags
            %219550,219570;220360,220440;224710,224730;230450,230600; % G12.91 flags
            %219720,219760;220370,220420;224690,224730;230450,230600; % G19.61 flags
            %224690,224730;230500,230650; % G24.33 flags
            %219550,219580;220380,220460;224690,224730;230500,230640; % G24.78 flags
            %219560,219600;220580,220610; 230520,230630; % G29.96 flags
            %219550,219570;220390,220410;224690,224730;230500,230600; % G31.41 flags
            %219550,219570;220380,220420;224690,224730;230490,230610; % G34.3 flags
            %219555,219570;220390,220450;224705,224725;230520,230600; % G45.47 flags
            %219550,219570;220380,220420;224705,224730;230500,230560; % G75.78 flags
            %224680,224780;230420,230700; % GCM+0.693 flags
            %219555,219565;220390,220410;224710,224730;230510,230560; % HH80 flags
            %220390,220430;230530,230560; % L1157 flags (this source doesn't have O isotopes)
            %219550,219565;220390,220400;224705,224715;230480,230600; % L1448MM flags
            %219555,219565;220390,220410;224710,224720;230520,230570; % NGC1333-2A flags
            %219550,219570;220100,220120;220390,220410;230530,230560; % NGC1333-2B flags
            %219550,219570;220390,220410;224710,224720;230510,230570; % NGC1333-4A flags
            %219550,219585;220380,220420;224700,224720;230500,230560; % NGC1333-4B flags
            %219550,219570;220380,220410;224700,224740;230500,230560; % NGC2264 flags
            %219940,219970;220380,220420;224690,224730;230500,230640; % NGC6334-29 flags
            %219550,219570;220390,220410;224700,224720;230500,230620; % NGC6334-38 flags
            %219550,219570;220390,220420;224705,224725;230500,230580; % NGC6334-43 flags
            %219550,219570;220390,220420;224710,224725;230510,230640; % NGC6334-IN flags
            %219550,219570;220380,220420;224700,224730;230510,230560; % NGC7538 flags
            %230400,230900; % Orion flags
            %220340,220440; 230400,230700; % SgrB2 flags
            %219550,219570;220380,220410;224690,224730;230480,230600; % W3 flags
            %219380,219430;219540,219580;220380,220420;224680,224720;230500,230580; % W51 flags
            %224700,224730;230500,230590; % W75N flags
            658520,658600;661000,661130;674000,674040; % HifiBand2 flags
            %1151600,1152300;1152900,1153300;1162650,1163100; % HifiBand5 flags
            ];
%
% Propogate uncertantity from (true) fit,
% (false) noise level before deconvolution
ta_err_from_fit = true; % Default is true
% noise level of antenna temperature (K)
ta_err_deconv = .03; % discarded if ta_err_from_fit = true

% >>>>>>>>>>>> CATALOG SECTION >>>>>>>>>>>>
%
% 'molpath' define catalog paths. Must match 'comp_num'
% 'parpath' define partition function data paths. Must match 'comp_num'
% 'label' define labels for each components for output. Must match 'comp_num'
% 'label' can be left blank if one is too lazy to type in any names.
%
molpath = {
           '../CatalogFile/CH3CN.txt';
           '../CatalogFile/CH2NH.txt';
           '../CatalogFile/CH3OH.txt';
           '../CatalogFile/C-13-H3OH.txt';
           '../CatalogFile/CH3OCH3.txt';
           '../CatalogFile/H2CO.txt';
           '../CatalogFile/H2CS.txt';
           '../CatalogFile/H2S.txt';
           '../CatalogFile/NO.txt';
           '../CatalogFile/SO2.txt';
           '../CatalogFile/S-34-O.txt';
           '../CatalogFile/S-34-O2.txt';
           };

parpath = {
           '../CatalogFile/CH3CNpar.par';
           '../CatalogFile/CH2NHpar.par';
           '../CatalogFile/CH3OHpar.par';
           '../CatalogFile/C-13-H3OHpar.par';
           '../CatalogFile/CH3OCH3par.par';
           '../CatalogFile/H2COpar.par';
           '../CatalogFile/H2CSpar.par';
           '../CatalogFile/H2Spar.par';
           '../CatalogFile/NOpar.par';
           '../CatalogFile/SO2par.par';
           '../CatalogFile/S-34-Opar.par';
           '../CatalogFile/S-34-O2par.par';
           };

parco = {
	 '../CatalogFile/CH3CNpar.co';
	 '../CatalogFile/CH2NHpar.co';
	 '../CatalogFile/CH3OHpar.co';
	 '../CatalogFile/C-13-H3OHpar.co';
         '../CatalogFile/CH3OCH3par.co';
         '../CatalogFile/H2COpar.co';
         '../CatalogFile/H2CSpar.co';
         '../CatalogFile/H2Spar.co';
         '../CatalogFile/NOpar.co';
         '../CatalogFile/SO2par.co';
         '../CatalogFile/S-34-Opar.co';
         '../CatalogFile/S-34-O2par.co';
         };

label = {
         'CH3CN';
         'CH2NH';
         'CH3OH';
         'C-13-H3OH';
         'CH3OCH3';
         'H2CO';
         'H2CS';
         'H2S';
         'NO';
         'SO2';
         'S-34-O';
         'S-34-O2';
         };
%
% The transition frequency uncertanty cut-off in MHz from the catalog.
% Frequencies with uncertainty exeeding this cut-off will not be imported.
% 0 if no cut-off desired.
freq_uc_cutoff = 1;
% The log intensity cut-off from the catalog. Transistions weaker than this
% cut-off will not be imported. Should be a negative number.
% 0 if no cut-off desired.
int_cutoff = 0;
% The lower state energy cut-off from the catalog. Lower state energy larger
% than the cut-off will not be imported. Unit in wavenumbers.
% 0 if no cut-off specified.
elow_cutoff = 0;

% >>>>>>>>>>>> FIT PARAMETER SECTION  >>>>>>>>>>>> 
%
% Options for 'patternsearch' algorithm. Customize when necessary.
options = psoptimset('Display','iter','MaxIter',10000,'MaxFunEval',...
    10000*comp_num*5,'MaxMeshSize',Inf,'MeshAccelerator','On',...
    'ScaleMesh','On','UseParallel','always','CompletePoll','On',...
    'TolMesh',1e-10,'TolX',1e-10,'TolFun',1e-10,'InitialMeshSize',1);

% Boundaries and initial guess of fitted parameters. Must match 'comp_num'
% The four paramters are:
% log(NT) (log10 cm^(-2)), FWHM (km/s), 0.01*Temp (100K), Shift (km/s)
low = repmat([10;2;0;-5],1,comp_num);

up = repmat([20;15;8;5],1,comp_num);

init = repmat([15;5;1;0],1,comp_num);

% The fraction used in calculating uncertainty
tol = 1e-3;

% >>>>>>>>>>>> OUTPUT & PREVIOUS FITS SECTION  >>>>>>>>>>>> 
%
% Define output path and file name. 
outputpath = '../Fit/v5.0/HifiBand2/G12.91/'; % Don't forget the last '/'
outputname = 'G12.91_cwtest1_XII-MOL_';
%
% Include previous fits. Only compatible with v4.0 or later versions
pfitpath = {
            '../Fit/v5.0/HifiBand2/G12.91/G12.91_pick_N2H+_Fit.csv';
            '../Fit/v5.0/HifiBand2/G12.91/G12.91_pick_H2C-13-O_Fit.csv';
            '../Fit/v5.0/HifiBand2/G12.91/G12.91_pick_CS-34_Fit.csv';
            };
