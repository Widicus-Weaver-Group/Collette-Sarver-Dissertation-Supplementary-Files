% *************************************************************************
% Description: Define varibles and paths for a fitting job
% Author: Mary L. Radhuber
% Date: April 24, 2013
% Developer: Luyao Zou
% v2.0: Dec. 25, 2013
% v2.1: Mar. 28, 2014
% v3.2: Aug. 7, 2014
% v4.1: Sept. 13, 2014
% v4.3: Feb. 15, 2015
% v4.4: Jun. 18, 2015
% v4.5: Dec. 1, 2015
% v5.0: Feb. 3, 2017
% *************************************************************************

% >>>>>>>>>>>> OBSERVATIONAL DATA SECTION >>>>>>>>>>>>
%
% Set number of components to fit
comp_num = 2;
%
% Path of observational x,y data
%obspath = '../Observation/IRAS-4B-s1-spectrum.csv';
%obspath = '../Observation/IRAS-4B-N1-spectrum.csv';
%obspath = '../Observation/779_tempcorrected-N2.csv';
%obspath='D:\IRAS-4B\MultObs\S-1\185_tempcorrected.csv'
obspath = '../Observation/IRAS-4B-RC-spectrum-k-base.csv';
%obspath = '../Observation/208_tempcorrected_middle_outflow.csv';
%obspath='../Parameter_Maps_GOBASIC/MultObs/233_tempcorrected.csv'
% Main beam efficiency of the telescope
apeff = 1;
%
% This 'range' is used to generate 'jlabel'. The value is determined
% by the user, which stands for how many datapoints on each side of the 
% molecular line center are going to be used to calculate gaussian line
% profile. Usually 10*fwhm/(sampling interval) is enough.
% DO NOT CHANGE this value! Changing it will cause error in including 
% previous fitting results.
range = 200;
%
% Source sizes for each component. If 0, no beam-filling factor is accounted.
% If the source is not circular, please enter the HPFD of the equivilant
% circular Gaussian profile.
% Unit in arcsec. Numbers of source sizes should match 'comp_num'
sourcesize = zeros(1,comp_num);
% Dish diameter of the telescope in meter
dish = 368;
%
% Frequency ranges to be flagged. Enter frequency window in MHz row by row.
% Leave blank as "flagfreq = [];" if no flagging is needed.
flagfreq = [135442,142920; %middle
     146612,146622; %methanol maser 146618
     132886,132898; %methanol maser 132890
     127364,127410; %antenna flux drops
     127558,127570; %antenna flux drops
     131418,131452; %antenna flux drops
     135304,135312; %absorption
     144074,144078; %absorption
     145090,145108; %methanol absorption #increase flag for whole transition, affected by absorption
     145600,145606; %methanol absorption
     146914,146938; %antenna flux drops
     146968,146974; %absorption
     150904,150988; %end of band, don't trust
     127652,127660; %optically thick 127656
     129430,129436; %optically thick 129432
     133452,133460; %optically thick 133456
     134228,134232; %became optically thick 134230 Yes in first round
     143104,143110; %became optically thick 143108 Yes in first round
     145760,145766; %became optically thick 145766 Yes in first round
     150880,150886; %became optically thick 150884 Yes in first round
     %%2nd round 2nd time
%      147392,147398; %optically thick, blended with HCOOCH3? 147396
%      148106,148116; %2nd time became optically thick 148108
%      150136,150144; %2nd time became optically thick 150140
%      150490,150502; %2nd time absorption/became optically thick
     %134620,134628; %optically thick 134624 Not in first round
     %147392,147398 %optically thick, blended with HCOOCH3? 147396 Not in first round
     %150136,150144; %optically thick 150140 Not in first round
%%%%%%% S-1
%       143860,143872; %optically thick 143866 S-1
%%%%%%% N-1
        %133600,133608; %barely optically thick 133604
%%%%%%% N-2
%        133600,133608; %barely optically thick 133604
%        143860,143872; %optically thick 143866 N-2
    ];

%
% Propogate uncertantity from (true) fit,
% (false) noise level before deconvolution
ta_err_from_fit = true; % Default is true
% noise level of antenna temperature (K)
ta_err_deconv = .03; % discarded if ta_err_from_fit = true

% >>>>>>>>>>>> CATALOG SECTION >>>>>>>>>>>>
%
% 'molpath' define catalog paths. Must match 'comp_num'
% 'parpath' define partition function data paths. Must match 'comp_num'
% 'label' define labels for each components for output. Must match 'comp_num'
% 'label' can be left blank if one is too lazy to type in any names.

molpath = {
%            '../CatalogFile/CH3OH_CDMS.txt';
%            '../CatalogFile/CH3OD.txt';
%            '../CatalogFile/C-13-H3OH.txt';
%             '../CatalogFile/CH2DOH.txt';
%             '../CatalogFile/CH3OCH3.txt';
%            '../CatalogFile/HCOOCH3.txt';
%            '../CatalogFile/CH3CHO.txt';
%            '../CatalogFile/C2H5OH.txt';
%            '../CatalogFile/CH2OHCHO.txt';
%            '../CatalogFile/HNCO.txt'
%            '../CatalogFile/CH3COCH3.txt'
%%%%%
          %'../CatalogFile/CH3OH_CDMS.txt';
          %'../CatalogFile/H2CO.txt';
           %'../CatalogFile/SO2.txt';
           %'../CatalogFile/CH3CN.txt';
           %'../CatalogFile/C2H3CN-15.txt'
           %'../CatalogFile/H2CS.txt'
           %'../CatalogFile/SiO.txt';
           %'../CatalogFile/SO.txt';
           %'../CatalogFile/CN.txt';
           %'../CatalogFile/CS.txt';
           %'../CatalogFile/OCS.txt'
           %'../CatalogFile/H2CO.txt';
           %'../CatalogFile/HCN.txt';
           %'../CatalogFile/C4H.txt';
           %'../CatalogFile/t-HCOOH.txt';
           %'../CatalogFile/C2H5CN.txt';
           %'../CatalogFile/C2H3CN.txt';
           %'../CatalogFile/CH3O-13-CHO.txt';
           %'../CatalogFile/HDCO.txt';
           %'../CatalogFile/c-C2H4O.txt';
           %'../CatalogFile/CH3CCH.txt';
           %'../CatalogFile/CH2NH.txt';
           %'../CatalogFile/H2CCO.txt';
           %'../CatalogFile/HCCCN.txt';
           %'../CatalogFile/HCCCN-15.txt';
           %'../CatalogFile/HCOOH.txt';
           %'../CatalogFile/NH2CHO.txt';
           %'../CatalogFile/c-HCCCH.txt';
           %'../CatalogFile/HCOCN.txt';
           %'../CatalogFile/13-CH3CN.txt';
           %'../CatalogFile/S-18-O.txt';
           %'../CatalogFile/29-SiC2.txt';
           %'../CatalogFile/H2S.txt';
           %'../CatalogFile/i-C3H7CN.txt';
           %'../CatalogFile/H2CS-34.txt';
           %'../CatalogFile/gGg-glycol.txt';
           %'../CatalogFile/aGg-glycol.txt';
           %'../CatalogFile/NO.txt';
           %'../CatalogFile/CH3NH2.txt';
           %'../CatalogFile/HDO.txt';
           %'../CatalogFile/CH3CDO.txt';
           %'../CatalogFile/CS-34.txt';
           %'../CatalogFile/SOO-17.txt';
           %'../CatalogFile/CH3C-13-N.txt';
           %'../CatalogFile/CH3COOHv0.txt';
           %'../CatalogFile/DCNv=0.txt';
           %'../CatalogFile/CH3O-13-CHO.txt';
           %'../CatalogFile/CH3-13-CHO.txt';
           %'../CatalogFile/13-CH3CHO.txt';
           %'../CatalogFile/S-34-O2.txt';
           %'../CatalogFile/HC-13-CCN.txt';
           %'../CatalogFile/HCC-13-CN.txt';
           %'../CatalogFile/HCCC-13-N.txt';
           %'../CatalogFile/CH3CNv8.txt';
           %'../CatalogFile/C-13-H3CH2CN.txt';
           %'../CatalogFile/a-C2H5OD.txt';
           %'../CatalogFile/c-C6H5OH.txt';
           %'../CatalogFile/HC7Nv15.txt';
           %'../CatalogFile/S2Ov0.txt';
           %'../CatalogFile/S4.txt';
           %'../CatalogFile/CH2Cl2-mod.txt';
           %'../CatalogFile/CH3COOHv0.txt';
           %'../CatalogFile/C2H5OOCH.txt';
           %'../CatalogFile/CH3SH.txt';
           %'../CatalogFile/HOONO2.txt';
           %'../CatalogFile/t-HCOOD.txt';
           %'../CatalogFile/CH3C5N.txt';
           %'../CatalogFile/CH2CDCN.txt';
           %'../CatalogFile/CH3SD.txt';
           %'../CatalogFile/CH3OCH2OH.txt';
           %'../CatalogFile/CH3-18-OH.txt';
           %'../CatalogFile/DCCCN.txt';
           %'../CatalogFile/CH2OH-13-CHO.txt';
           %'../CatalogFile/H2S.txt'
           %'../CatalogFile/C2H5CNv20-A.txt'
           %'../CatalogFile/C2H3NC.txt'
           %'../CatalogFile/H2CCCHCN.txt'
           %'../CatalogFile/g-C2H5SH.txt'
           '../CatalogFile/C5O.txt'
           %'../CatalogFile/H2C-13-O.txt'
           %'../CatalogFile/HO-13-CO+.txt'
           %'../CatalogFile/C3H.txt'
           %'../CatalogFile/c-CC-13-CH2.txt'
           %'../CatalogFile/NH2OH.txt'
           %'../CatalogFile/NH2CHO.txt'
           %'../CatalogFile/HONO.txt'
           %'../CatalogFile/O-13-CS.txt'
           '../CatalogFile/CNCN.txt'
           %'../CatalogFile/c-H2C3O.txt'
           %'../CatalogFile/CS-33.txt'
           %'../CatalogFile/CH3-13-CH2CN.txt'
           %'../CatalogFile/HCS+.txt';
           %'../CatalogFile/C8H-.txt';
           %'../CatalogFile/C-13-CCS.txt';
           %'../CatalogFile/n-C3H7CN.txt';
           %'../CatalogFile/D2CS.txt';
           %'../CatalogFile/HDS.txt';
           %'../CatalogFile/CCH.txt';
           %'../CatalogFile/CO.txt';
           };

parpath = {
%            '../CatalogFile/CH3OH_CDMS.par';
%            '../CatalogFile/CH3OD.par';
%            '../CatalogFile/C-13-H3OHpar.par';
%             '../CatalogFile/CH2DOHpar.par';
%             '../CatalogFile/CH3OCH3par.par';
%            '../CatalogFile/HCOOCH3par.par';
%            '../CatalogFile/CH3CHOpar.par';
%            '../CatalogFile/C2H5OHpar.par';
%            '../CatalogFile/CH2OHCHOpar.par';
%            '../CatalogFile/HNCOpar.par';
%            '../CatalogFile/CH3COCH3par.par';
%%%%%%
          %'../CatalogFile/CH3OH_CDMS.par';
           %'../CatalogFile/H2COpar.par';
           %'../CatalogFile/SO2par.par';
           %'../CatalogFile/CH3CNpar.par';
           %'../CatalogFile/C2H3CN-15par.par';
           %'../CatalogFile/H2CSpar.par'
           %'../CatalogFile/SiOpar.par';
           %'../CatalogFile/SOpar.par';
           %'../CatalogFile/CNpar.par';
           %'../CatalogFile/CSpar.par';
           %'../CatalogFile/OCSpar.par';
           %'../CatalogFile/H2COpar.par';
           %'../CatalogFile/HCNpar.par';
           %'../CatalogFile/C4Hpar.par';
           %'../CatalogFile/t-HCOOHpar.par';
           %'../CatalogFile/C2H5CNpar.par';
           %'../CatalogFile/C2H3CNpar.par';
           %'../CatalogFile/CH3O-13-CHOpar.par';
           %'../CatalogFile/HDCOpar.par';
           %'../CatalogFile/c-C2H4Opar.par'
           %'../CatalogFile/CH3CCHpar.par'
           %'../CatalogFile/CH2NHpar.par'
           %'../CatalogFile/H2CCOpar.par'
           %'../CatalogFile/HCCCNpar.par';
           %'../CatalogFile/HCCCN-15par.par';
           %'../CatalogFile/HCOOHpar.par'
           %'../CatalogFile/NH2CHOpar.par'
           %'../CatalogFile/c-HCCCHpar.par'
           %'../CatalogFile/HCOCNpar.par'
           %'../CatalogFile/13-CH3CN.par'
           %'../CatalogFile/S-18-Opar.par'
           %'../CatalogFile/29-SiC2par.par'
           %'../CatalogFile/H2Spar.par'
           %'../CatalogFile/i-C3H7CNpar.par'
           %'../CatalogFile/H2CS-34par.par'
           %'../CatalogFile/gGg-glycolpar.par'
           %'../CatalogFile/aGg-glycolpar.par'
           %'../CatalogFile/NOpar.par';
           %'../CatalogFile/CH3NH2par.par';
           %'../CatalogFile/HDOpar.par';
           %'../CatalogFile/CH3CDO.par';
           %'../CatalogFile/CS-34par.par';
           %'../CatalogFile/SOO-17par.par';
           %'../CatalogFile/CH3C-13-Npar.par';
           %'../CatalogFile/CH3COOH.par';
           %'../CatalogFile/DCNv=0.par';
           %'../CatalogFile/CH3O-13-CHO.par';
           %'../CatalogFile/CH3-13-CHO.par';
           %'../CatalogFile/13-CH3CHO.par';
           %'../CatalogFile/S-34-O2par.par';
           %'../CatalogFile/HC-13-CCNpar.par';
           %'../CatalogFile/HCC-13-CNpar.par';
           %'../CatalogFile/HCCC-13-Npar.par';
           %'../CatalogFile/CH3CNv8par.par';
           %'../CatalogFile/C-13-H3CH2CNpar.par';
           %'../CatalogFile/a-C2H5OD.par';
           %'../CatalogFile/c-C6H5OH.par';
           %'../CatalogFile/HC7Nv15.par';
           %'../CatalogFile/S2Ov0.par';
           %'../CatalogFile/S4.par';
           %'../CatalogFile/CH2Cl2.par';
           %'../CatalogFile/CH3COOH.par';
           %'../CatalogFile/C2H5OOCH.par';
           %'../CatalogFile/CH3SHpar.par';
           %'../CatalogFile/HOONO2.par';
           %'../CatalogFile/t-HCOOD.par';
           %'../CatalogFile/CH3C5N.par';
           %'../CatalogFile/CH2CDCN.par';
           %'../CatalogFile/CH3SD.par';
           %'../CatalogFile/CH3OCH2OH.par';
           %'../CatalogFile/CH2C-13-HCNpar.par';
           %'../CatalogFile/CH3-18-OHpar.par';
           %'../CatalogFile/DCCCNpar.par';
           %'../CatalogFile/CH2OH-13-CHO.par';
           %'../CatalogFile/H2Spar.par';
           %'../CatalogFile/C2H5CNv20-A.par';
           %'../CatalogFile/C2H3NC.par';
           %'../CatalogFile/H2CCCHCN.par';
           %'../CatalogFile/g-C2H5SH.par';
           '../CatalogFile/C5O.par';
           %'../CatalogFile/H2C-13-Opar.par';
           %'../CatalogFile/HO-13-CO+.par';
           %'../CatalogFile/C3H.par';
           %'../CatalogFile/c-CC-13-CH2.par';
           %'../CatalogFile/NH2OH.par';
           %'../CatalogFile/NH2CHOpar.par';
           %'../CatalogFile/HONO.par';
           %'../CatalogFile/O-13-CS.par';
           '../CatalogFile/CNCN.par';
           %'../CatalogFile/c-H2C3O.par';
           %'../CatalogFile/CS-33par.par';
           %'../CatalogFile/CH3-13-CH2CN.par';
           %'../CatalogFile/HCS+par.par';
           %'../CatalogFile/C8H-.par';
           %'../CatalogFile/C-13-CCS.par';
           %'../CatalogFile/n-C3H7CNpar.par';
           %'../CatalogFile/D2CS.par';
           %'../CatalogFile/HDSpar.par';
           %'../CatalogFile/CCHpar.par';
           %'../CatalogFile/COpar.par';
           };

parco = {
%          '../CatalogFile/CH3OH_CDMS.co';
%          '../CatalogFile/CH3OD-new.co';
%          '../CatalogFile/C-13-H3OHpar.co';
%           '../CatalogFile/CH2DOHpar.co';
%           '../CatalogFile/CH3OCH3par.co';
%          '../CatalogFile/HCOOCH3par.co';
%          '../CatalogFile/CH3CHOpar.co';
%          '../CatalogFile/C2H5OHpar.co';
%          '../CatalogFile/CH2OHCHOpar.co';
%          '../CatalogFile/HNCOpar.co';
%          '../CatalogFile/CH3COCH3par.co';
          %'../CatalogFile/CH3OH_CDMS.co';
         % '../CatalogFile/H2COpar.co';
         %'../CatalogFile/SO2par.co';
         %'../CatalogFile/CH3CNpar.co';
         %'../CatalogFile/C2H3CN-15par.co'
         %'../CatalogFile/H2CSpar.co'
         %'../CatalogFile/SiOpar.co';
         %'../CatalogFile/SOpar.co';
         %'../CatalogFile/CNpar.co';
         %'../CatalogFile/CSpar.co';
         %'../CatalogFile/OCSpar.co';
         %'../CatalogFile/H2COpar.co';
         %'../CatalogFile/HCNpar.co';
         %'../CatalogFile/C4Hpar.co';
         %'../CatalogFile/t-HCOOHpar.co';
         %'../CatalogFile/C2H5CNpar.co';
         %'../CatalogFile/C2H3CNpar.co';
         %'../CatalogFile/CH3O-13-CHOpar.co'
         %'../CatalogFile/HDCO.co'
         %'../CatalogFile/c-C2H4Opar.co'
         %'../CatalogFile/CH3CCHpar.co'
         %'../CatalogFile/CH2NHpar.co'
         %'../CatalogFile/H2CCOpar.co'
         %'../CatalogFile/HCCCNpar.co';
         %'../CatalogFile/HCCCN-15par.co';
         %'../CatalogFile/HCOOHpar.co'
         %'../CatalogFile/NH2CHOpar.co'
         %'../CatalogFile/c-HCCCHpar.co'
         %'../CatalogFile/HCOCNpar.co'
         %'../CatalogFile/13-CH3CN.co'
         %'../CatalogFile/S-18-Opar.co'
         %'../CatalogFile/29-SiC2par.co'
         %'../CatalogFile/H2Spar.co'
         %'../CatalogFile/i-C3H7CNpar.co'
         %'../CatalogFile/H2CS-34par.co'
         %'../CatalogFile/gGg-glycolpar.co'
         %'../CatalogFile/aGg-glycolpar.co'
         %'../CatalogFile/NOpar.co';
         %'../CatalogFile/CH3NH2par.co';
         %'../CatalogFile/HDOpar.co';
         %'../CatalogFile/CH3CDO.co';
         %'../CatalogFile/CS-34par.co';
         %'../CatalogFile/SOO-17par.co';
         %'../CatalogFile/CH3C-13-Npar.co';
         %'../CatalogFile/CH3COOH.co';
         %'../CatalogFile/DCNv=0.co';
         %'../CatalogFile/CH3O-13-CHO.co';
         %'../CatalogFile/CH3-13-CHO.co';
         %'../CatalogFile/13-CH3CHO.co';
         %'../CatalogFile/S-34-O2par.co';
         %'../CatalogFile/HC-13-CCNpar.co';
         %'../CatalogFile/HCC-13-CNpar.co';
         %'../CatalogFile/HCCC-13-Npar.co';
         %'../CatalogFile/CH3CNv8par.co';
         %'../CatalogFile/C-13-H3CH2CNpar.co';
         %'../CatalogFile/a-C2H5OD.co';
         %'../CatalogFile/c-C6H5OH.co';
         %'../CatalogFile/HC7Nv15.co';
         %'../CatalogFile/S2Ov0.co';
         %'../CatalogFile/S4.co';
         %'../CatalogFile/CH2Cl2.co';
         %'../CatalogFile/CH3COOH.co';
         %'../CatalogFile/C2H5OOCH.co';
         %'../CatalogFile/CH3SHpar.co';
         %'../CatalogFile/HOONO2.co';
         %'../CatalogFile/t-HCOOD.co';
         %'../CatalogFile/CH3C5N.co';
         %'../CatalogFile/CH2CDCN.co';
         %'../CatalogFile/CH3SD.co';
         %'../CatalogFile/CH3OCH2OH.co';
         %'../CatalogFile/CH2C-13-HCNpar.co';
         %'../CatalogFile/CH3-18-OHpar.co';
         %'../CatalogFile/DCCCNpar.co';
         %'../CatalogFile/CH2OH-13-CHO.co';
         %'../CatalogFile/H2Spar.co';
         %'../CatalogFile/C2H5CNv20-A.co';
         %'../CatalogFile/C2H3NC.co';
         %'../CatalogFile/H2CCCHCN.co';
         %'../CatalogFile/g-C2H5SH.co';
         '../CatalogFile/C5O.co';
         %'../CatalogFile/H2C-13-Opar.co';
         %'../CatalogFile/HO-13-CO+.co';
         %'../CatalogFile/C3H.co';
         %'../CatalogFile/c-CC-13-CH2.co';
         %'../CatalogFile/NH2OH.co';
         %'../CatalogFile/NH2CHOpar.co';
         %'../CatalogFile/HONO.co';
         %'../CatalogFile/O-13-CS.co';
         '../CatalogFile/CNCN.co';
         %'../CatalogFile/c-H2C3O.co';
         %'../CatalogFile/CS-33par.co';
         %'../CatalogFile/CH3-13-CH2CN.co'
         %'../CatalogFile/HCS+par.co';
         %'../CatalogFile/C8H-.co';
         %'../CatalogFile/C-13-CCS.co';
         %'../CatalogFile/n-C3H7CNpar.co';
         %'../CatalogFile/D2CS.co';
         %'../CatalogFile/HDSpar.co';
         %'../CatalogFile/CCHpar.co';
         %'../CatalogFile/COpar.co';
         };

label = {
%          'CH3OH';
%          'CH3OD';
%          'C-13-H3OH';
%           'CH2DOH';
%           'CH3OCH3';
%          'HCOOCH3';
%          'CH3CHO';
%          'C2H5OH';
%          'CH2OHCHO';
%          'HNCO';
%          'CH3COCH3';
%%%%%%
          %'CH3OH'
         % 'H2CO'
         %'SO2';
         %'CH3CN';
         %'C2H3CNv15';
         %'H2CS';
         %'SiO';
         %'SO';
         %'CN';
         %'CS';
         %'OCS';
         %'H2CO';
         %'HCN';
         %'C4H';
         %'t-HCOOH'
         %'C2H5CN';
         %'C2H3CN';
         %'CH3O-13-CHO'
         %'HDCO'
         %'c-C2H4O'
         %'CH3CCH'
         %'CH2NH'
         %'H2CCO'
         %'HCCCN'
         %'HCCCN-15';
         %'HCC13CN'
         %'HCOOH'
         %'NH2CHO'
         %'c-HCCCH'
         %'HCOCN'
         %'13-CH3CN'
         %'S-18-O'
         %'29-SiC2'
         %'H2S'
         %'C2H3C-13-N'
         %'i-C3H7CN'
         %'H2CS-34'
         %'Ethylene-glycol-gGg'
         %'Ethylene-glycol-aGg'
         %'NO';
         %'CH3NH2'
         %'HDO'
         %'CH3CDO';
         %'C34S';
         %'SO17O';
         %'CH3-13-CN';
         %'acetic-acid';
         %'DCNv=0';
         %'CH3O-13-CHO';
         %'CH3-13-CHO';
         %'13-CH3CHO';
         %'34-SO2';
         %'H-13-CCCN'
         %'CH3CNv8'
         %'13-C2H5CN'
         %'a-C2H5OD'
         %'c-C6H5OH'
         %'HC7Nv15'
         %'S2Ov0'
         %'S4'
         %'CH2Cl2'
         %'CH3COOH'
         %'C2H5OOCH'
         %'CH3SH'
         %'HOONO2'
         %'t-HCOOD'
         %'CH3C5N'
         %'CH2CDCN'
         %'CH3SD'
         %'CH3OCH2OH'
         %'CH2-13-CHCN'
         %'CH3-18-OH'
         %'DC3N'
         %'CH2OH-13-CHO'
         %'H2S'
         %'C2H5CNv20-A'
         %'C2H3NC'
         %'H2CCCHCN'
         %'g-C2H5SH'
         'C5O'
         %'H2-13-CO'
         %'HO-13-CO+'
         %'C3H'
         %'c-CC-13-CH2'
         %'NH2OH'
         %'NH2CHO'
         %'HONO'
         %'O-13-CS'
         'CNCN'
         %'c-H2C3O'
         %'CH3-13-CH2CN'
         %'HCS+'
         %'C8H-'
         %'C-13-CCS'
         %'n-C3H7CN';
         %'D2CS';
         %'HDS';
         %'CCH';
         %'CO';
         };
%
% The transition frequency uncertanty cut-off in MHz from the catalog.
% Frequencies with uncertainty exeeding this cut-off will not be imported.
% 0 if no cut-off desired.
freq_uc_cutoff = 1;
% The log intensity cut-off from the catalog. Transistions weaker than this
% cut-off will not be imported. Should be a negative number.
% 0 if no cut-off desired.
int_cutoff = 0;
% The lower state energy cut-off from the catalog. Lower state energy larger
% than the cut-off will not be imported. Unit in wavenumbers.
% 0 if no cut-off specified.
elow_cutoff = 0;

% >>>>>>>>>>>> FIT PARAMETER SECTION  >>>>>>>>>>>> 
%
% Options for 'patternsearch' algorithm. Customize when necessary.
options = psoptimset('Display','iter','MaxIter',50000,'MaxFunEval',...
    500000*comp_num*5,'MaxMeshSize',Inf,'MeshAccelerator','On',...
    'ScaleMesh','On','UseParallel','Always','CompletePoll','On',...
    'TolMesh',1e-10,'TolX',1e-10,'TolFun',1e-10,'InitialMeshSize',1);

% Boundaries and initial guess of fitted parameters. Must match 'comp_num'
% The four paramters are:
% log(NT) (log10 cm^(-2)), FWHM (km/s), 0.01*Temp (100K), velocity Shift (km/s)
low = repmat([12;0.50;0.01;-12],1,comp_num);%13;1.00;0.05;-8

up = repmat([19;20;5.00;12],1,comp_num);%19;20;5.00;3

init = repmat([15;5;1.5;0],1,comp_num);%15;5;1.5;0
% init=[15.48,14.92;
%       8.31,8.19;
%       0.1609,0.3108;
%       -0.004,-0.91;
% ];
% The fraction used in calculating uncertainty
tol = 1e-3;

% >>>>>>>>>>>> OUTPUT & PREVIOUS FITS SECTION  >>>>>>>>>>>> 
%
% Define output path and file name. 
outputpath = '../Fit/IRAS-4B-RC/'; % Don't forget the last '/'
outputname = 'CNCN-C5O-with-pf'; %11-molecules-42-previous-fits-methanol-masers-flagged%
% Include previous fits. Only compatible with v4.0 or later versions
pfitpath = {
%     '../Fit/IRAS-4B-RC/Final-Fits/11-molecules-37-pf-masers-absorption-first-round-optically-thick-flagged-new-co-valuesFit.csv'
%        '../Fit/IRAS-4B-RC/Final-Fits/bulk-final-fit-no-CH2DOH-CH3OCH3.csv'
%     %%%%%%%
          '../Fit/IRAS-4B-RC/HDCO-test-alone-new-co-valuesFit.csv'
          '../Fit/IRAS-4B-RC/CH3CNFit.csv'
          '../Fit/IRAS-4B-RC/Final-Fits/OCSFit.csv'
          '../Fit/IRAS-4B-RC/Final-Fits/SO-with-previous-fits-9Fit.csv'
         '../Fit/IRAS-4B-RC/Final-Fits/SO2-with-previous-fits-9Fit.csv'
         '../Fit/IRAS-4B-RC/Final-Fits/H2CS-with-previous-fits-12Fit.csv'
         '../Fit/IRAS-4B-RC/Final-Fits/HCCCNFit.csv'
         '../Fit/IRAS-4B-RC/Final-Fits/HCCCNv6-with-previous-fits-14Fit.csv'
         '../Fit/IRAS-4B-RC/New-co-values/HCCCN-15-with-8-previous-fits-11-bulk-pfFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/SiOFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/HDOFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/C34SFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/DCNv0Fit.csv'
        '../Fit/IRAS-4B-RC/New-co-values/13CH3CHO-with-13-pf-11-bulk-pfFit.csv'
        '../Fit/IRAS-4B-RC/New-co-values/H13CCCNFit.csv'
        '../Fit/IRAS-4B-RC/New-co-values/HC13CCNFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/CH3CNv8Fit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/t-HCOOH-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/CH3SH-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/Final-Fits/H2C-34-SFit.csv'
        '../Fit/IRAS-4B-RC/C2H5CNv20-A-C2H5CN-with-previous-fitsFit.csv'
        %%%'../Fit/IRAS-4B-RC/H3CCHCH2O-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/g-C2H5SH-with-previous-fitsFit.csv'
        %'../Fit/IRAS-4B-RC/H2-13-COFit.csv'
        '../Fit/IRAS-4B-RC/NH2OHFit.csv'
        '../Fit/IRAS-4B-RC/CNCN-C5O-with-pfFit.csv'
        '../Fit/IRAS-4B-RC/NH2CHO-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/cis-HCONHD-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/HONO-with-previous-fitsFit.csv' 
        '../Fit/IRAS-4B-RC/O-13-CSFit.csv'
        %%%'../Fit/IRAS-4B-RC/c-H2C3O-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/CS-33-with-previous-fitsFit.csv'
        '../Fit/IRAS-4B-RC/CH3-18-OH-with-31-pf-11-bulk-pfFit.csv'
        '../Fit/IRAS-4B-RC/New-co-values/DCCCNFit.csv'
        '../Fit/IRAS-4B-RC/New-co-values/H2SFit.csv'
        '../Fit/IRAS-4B-RC/New-co-values/C3HFit.csv'
%%%%%%% S-1 Previous fits
% % '../Fit/IRAS-4B-S-1/CH3OH-no-flags-aloneFit.csv'
% % '../Fit/IRAS-4B-S-1/SiO-aloneFit.csv'
% % '../Fit/IRAS-4B-S-1/HDCO-aloneFit.csv'
% % '../Fit/IRAS-4B-S-1/H2CS-aloneFit.csv'
% % '../Fit/IRAS-4B-S-1/H2CO-aloneFit.csv'
% % '../Fit/IRAS-4B-S-1/CS-aloneFit.csv'
% % '../Fit/IRAS-4B-S-1/C-34-S-aloneFit.csv'
%%% S-1 Previous fits?
% '../Fit/IRAS-4B-RC/S1/HCCCNFit.csv'
% '../Fit/IRAS-4B-RC/S1/H2C-34-SFit.csv'
% '../Fit/IRAS-4B-RC/S1/SiOFit.csv'
% '../Fit/IRAS-4B-RC/S1/SOFit.csv'
% '../Fit/IRAS-4B-RC/S1/C34SFit.csv'
% '../Fit/IRAS-4B-RC/S1/HDCOFit.csv'
           };