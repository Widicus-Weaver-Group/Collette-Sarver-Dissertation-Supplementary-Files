molpath = {
           '../CatalogFile/CH3CCH.txt';
           '../CatalogFile/CH3CN.txt';
           '../CatalogFile/CH3OH.txt';
           '../CatalogFile/DME.txt';
           '../CatalogFile/HCCCN.txt';
           '../CatalogFile/HCOOCH3.txt';
           '../CatalogFile/SO2.txt';
           };

parpath = {
           '../CatalogFile/CH3CCHpar.par';
           '../CatalogFile/CH3CNpar.par';
           '../CatalogFile/CH3OHpar.par';
           '../CatalogFile/DMEpar.par';
           '../CatalogFile/HCCCNpar.par';
           '../CatalogFile/HCOOCH3par.par';
           '../CatalogFile/SO2par.par';
           };

label = {
         'CH3CCH';
         'CH3CN';
         'CH3OH';
         'DME';
         'HCCCN';
         'HCOOCH3';
         'SO2';
         };